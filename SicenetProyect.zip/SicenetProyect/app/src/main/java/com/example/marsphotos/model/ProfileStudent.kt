package com.example.marsphotos.model

import kotlinx.serialization.Serializable


data class ProfileStudent (val matricula : String) {
}
